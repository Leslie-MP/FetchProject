//
//  NetworkManagerTests.swift
//  FetchProject
//
//  Created by Leslie Mora Ponce on 12/10/24.
//

import XCTest
@testable import FetchProject

class NetworkManagerTests: XCTestCase {

    // test success using mock json
    func testFetchRecipesSuccess() {
        let mockJson = """
        {
            "recipes": [
                {
                            "cuisine": "American",
                            "name": "Banana Pancakes",
                            "photo_url_large": "https://d3jbb8n5wk0qxi.cloudfront.net/photos/b6efe075-6982-4579-b8cf-013d2d1a461b/large.jpg",
                            "photo_url_small": "https://d3jbb8n5wk0qxi.cloudfront.net/photos/b6efe075-6982-4579-b8cf-013d2d1a461b/small.jpg",
                            "source_url": "https://www.bbcgoodfood.com/recipes/banana-pancakes",
                            "uuid": "f8b20884-1e54-4e72-a417-dabbc8d91f12",
                            "youtube_url": "https://www.youtube.com/watch?v=kSKtb2Sv-_U"
                }
            ]
        }
        """.data(using: .utf8)!
        // mock with only the banana pancakes
        let session = MockURLSession(data: mockJson, error: nil)
        let networkManager = NetworkManager(session: session)
        
        let expectation = self.expectation(description: "FetchRecipes")
        
        networkManager.fetchRecipes(from: "https://d3jbb8n5wk0qxi.cloudfront.net/recipes.json") { result in
            switch result {
            case .success(let recipes):
                XCTAssertEqual(recipes.count, 1)
                XCTAssertEqual(recipes.first?.name, "Banana Pancakes")
                expectation.fulfill()
            case .failure(let error):
                XCTFail("Expected success, got failure with error: \(error)")
            }
        }
        
        waitForExpectations(timeout: 2.0, handler: nil)
    }
    
    func testFetchRecipesEmptyResponse() {
        let json = "{\"recipes\": []}".data(using: .utf8)!
        
        let session = MockURLSession(data: json, error: nil)
        let networkManager = NetworkManager(session: session)

        let expectation = self.expectation(description: "EmptyFetch")

        networkManager.fetchRecipes(from: "https://d3jbb8n5wk0qxi.cloudfront.net/recipes.json") { result in
            switch result {
            case .success(let recipes):
                XCTAssertEqual(recipes.count, 0)
                expectation.fulfill()
            case .failure:
                XCTFail("Expected empty response, got failure")
            }
        }
        waitForExpectations(timeout: 2.0, handler: nil)
    }

    func testFetchRecipesMalformedJSON() {
        
        let malformedJSON = """
        [
            {"name": "Pasta", "cuisine": "Italian"
        """
        .data(using: .utf8)!
        
        let mockSession = MockURLSession(data: malformedJSON, error: nil)
        let networkManager = NetworkManager(session: mockSession)
        
        let expectation = self.expectation(description: "FetchRecipesMalformedJSON")
        
        networkManager.fetchRecipes(from: "https://d3jbb8n5wk0qxi.cloudfront.net/recipes.json") { result in
            switch result {
            case .success:
                XCTFail("Expected failure, but got success")
            case .failure(let error):
               
                if let decodingError = error as? DecodingError {
                    switch decodingError {
                    case .dataCorrupted, .keyNotFound, .typeMismatch, .valueNotFound:
                        XCTAssertTrue(true, "Received decoding error as expected")
                    default:
                        XCTFail("Unexpected decoding error")
                    }
                } else {
                    XCTFail("Expected Decoding Error, but got \(error)")
                }
                expectation.fulfill()
            }
        }
        waitForExpectations(timeout: 2, handler: nil)
    }
}

//Mock class for returning mock data
class MockURLSession: URLSessionProtocol {
    private let data: Data?
    private let error: Error?

    init(data: Data?, error: Error?) {
        self.data = data
        self.error = error
    }

    func dataTask(with url: URL, completionHandler: @escaping (Data?, URLResponse?, Error?) -> Void) -> URLSessionDataTask {
        completionHandler(data, nil, error)
        // dummy task return
        return URLSession.shared.dataTask(with: url)
    }
}

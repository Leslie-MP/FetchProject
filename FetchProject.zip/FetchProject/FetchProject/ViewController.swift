//
//  ViewController.swift
//  FetchProject
//
//  Created by Leslie Mora Ponce on 11/25/24.
//
//name, photo, and cuisine type.
import UIKit

class ViewController: UIViewController {
    
    let tableView = UITableView()
    var recipes: [Recipe] = []
    let refreshControl = UIRefreshControl()
    
    let segmentedControl: UISegmentedControl = {
        let control = UISegmentedControl(items: ["Normal", "Malformed", "Empty"])
        control.selectedSegmentIndex = 0
        return control
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.title = "Recipes"
        view.backgroundColor = UIColor.systemGroupedBackground
        setupSegmentedControl()
        setupTableView()
        setupRefreshControl()
        //once ui is build we fetch recipes
        fetchRecipes(from: getSelectedURL())
        
    }
    
    func setupSegmentedControl() {
        view.addSubview(segmentedControl)
        segmentedControl.translatesAutoresizingMaskIntoConstraints = false
        
        
        NSLayoutConstraint.activate([
            segmentedControl.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: -5),
            segmentedControl.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            segmentedControl.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20)
        ])
        
        //add target to call function when user changes selection
        segmentedControl.addTarget(self, action: #selector(segmentChanged), for: .valueChanged)
    }
    func setupTableView() {
        view.addSubview(tableView)
        tableView.translatesAutoresizingMaskIntoConstraints = false
        
        NSLayoutConstraint.activate([
            tableView.topAnchor.constraint(equalTo: segmentedControl.bottomAnchor, constant: 10),
            tableView.bottomAnchor.constraint(equalTo: view.bottomAnchor),
            tableView.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            tableView.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20)
        ])
        
        tableView.register(RecipeCell.self, forCellReuseIdentifier: "RecipeCell")
        tableView.dataSource = self
        tableView.delegate = self
        
        tableView.refreshControl = refreshControl
    }
    
    func setupRefreshControl() {
        refreshControl.addTarget(self, action: #selector(handleRefresh), for: .valueChanged)
        refreshControl.tintColor = .gray
    }
    
    @objc func handleRefresh() {
        fetchRecipes(from: getSelectedURL()) // Reload recipes when pulled
    }
    
    func fetchRecipes(from urlString: String) {
        NetworkManager.shared.fetchRecipes(from: urlString) { result in
            DispatchQueue.main.async {
                self.refreshControl.endRefreshing() // Stop the refresh animation
                switch result {
                case .success(let fetchedRecipes):
                    if fetchedRecipes.isEmpty {
                        self.showAlert(title: "Error", message: "There are no recipes available.")
                    }
                    // update list of recipes
                    self.recipes = fetchedRecipes
                    self.tableView.reloadData()
                case .failure:
                    self.showAlert(title: "Error", message: "Unable to fetch recipes. The data is invalid.")
                    // clear recipes on error
                    self.recipes = []
                    self.tableView.reloadData()
                }
            }
        }
    }
    
    
    func showAlert(title: String, message: String) {
        let alertController = UIAlertController(title: title, message: message, preferredStyle: .alert)
        alertController.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
        self.present(alertController, animated: true, completion: nil)
    }
    
    @objc func segmentChanged() {
        let urlString = getSelectedURL()
        fetchRecipes(from: urlString)
    }
    func getSelectedURL() -> String {
        switch segmentedControl.selectedSegmentIndex {
        case 0:
            return "https://d3jbb8n5wk0qxi.cloudfront.net/recipes.json"
        case 1:
            return "https://d3jbb8n5wk0qxi.cloudfront.net/recipes-malformed.json"
        case 2:
            return "https://d3jbb8n5wk0qxi.cloudfront.net/recipes-empty.json"
        default:
            return "https://d3jbb8n5wk0qxi.cloudfront.net/recipes.json"
        }
    }
}
// MARK: - UITableViewDataSource

extension ViewController: UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return recipes.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: "RecipeCell", for: indexPath) as? RecipeCell else {
            return UITableViewCell()
        }
        
        //get the recipe tapped
        let recipe = recipes[indexPath.row]
        // update the cell
        cell.recipeLabel.text = recipe.name
        cell.cuisineLabel.text = recipe.cuisine
        
        cell.recipeImageView.image = UIImage(named: "placeholder")
        
        
        if let imageUrlString = recipe.photoUrlSmall, let imageUrl = URL(string: imageUrlString) {
            
            NetworkManager.shared.fetchImage(from: imageUrl) { result in
                switch result {
                case .success(let image):
                    DispatchQueue.main.async {
                        if let currentCell = tableView.cellForRow(at: indexPath) as? RecipeCell {
                            currentCell.recipeImageView.image = image
                        }
                    }
                    
                case .failure(let error):
                    print("Failed to load image: \(error.localizedDescription)")
                    
                }
            }
        }
        
        return cell
    }
    
    
}

// MARK: - UITableViewDelegate

extension ViewController: UITableViewDelegate {
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let selectedRecipe = recipes[indexPath.row]
        let detailVC = RecipeViewController()
        detailVC.recipe = selectedRecipe
        navigationController?.pushViewController(detailVC, animated: true)
    }
    
    
}


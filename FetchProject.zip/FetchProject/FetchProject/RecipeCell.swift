import UIKit

class RecipeCell: UITableViewCell {

    let recipeImageView: UIImageView = {
        let imageView = UIImageView()
        imageView.contentMode = .scaleAspectFill  
        imageView.clipsToBounds = true
        imageView.layer.cornerRadius = 10
        imageView.translatesAutoresizingMaskIntoConstraints = false
        return imageView
    }()

    let recipeLabel: UILabel = {
        let label = UILabel()
        label.font = UIFont.boldSystemFont(ofSize: 18)
        label.textColor = .black
        label.numberOfLines = 0
        label.translatesAutoresizingMaskIntoConstraints = false
        return label
    }()

    let cuisineLabel: UILabel = {
        let label = UILabel()
        label.font = UIFont.systemFont(ofSize: 14)
        label.textColor = .darkGray
        label.translatesAutoresizingMaskIntoConstraints = false
        return label
    }()

    let separator: UIView = {
        let view = UIView()
        view.backgroundColor = UIColor.lightGray.withAlphaComponent(0.5)
        view.translatesAutoresizingMaskIntoConstraints = false
        return view
    }()

    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)

        // Add subviews
        contentView.addSubview(recipeImageView)
        contentView.addSubview(recipeLabel)
        contentView.addSubview(cuisineLabel)
        contentView.addSubview(separator)

        NSLayoutConstraint.activate([
            recipeImageView.leadingAnchor.constraint(equalTo: contentView.leadingAnchor, constant: 10),
            recipeImageView.centerYAnchor.constraint(equalTo: contentView.centerYAnchor),
            recipeImageView.widthAnchor.constraint(equalToConstant: 60),
            recipeImageView.heightAnchor.constraint(equalToConstant: 60),
        ])

        NSLayoutConstraint.activate([
            recipeLabel.topAnchor.constraint(equalTo: contentView.topAnchor, constant: 10),
            recipeLabel.leadingAnchor.constraint(equalTo: recipeImageView.trailingAnchor, constant: 15),
            recipeLabel.trailingAnchor.constraint(equalTo: contentView.trailingAnchor, constant: -10),
        ])

        NSLayoutConstraint.activate([
            cuisineLabel.topAnchor.constraint(equalTo: recipeLabel.bottomAnchor, constant: 5),
            cuisineLabel.leadingAnchor.constraint(equalTo: recipeImageView.trailingAnchor, constant: 15),
            cuisineLabel.trailingAnchor.constraint(equalTo: contentView.trailingAnchor, constant: -10),
            cuisineLabel.bottomAnchor.constraint(equalTo: contentView.bottomAnchor, constant: -10),
        ])

        NSLayoutConstraint.activate([
            separator.heightAnchor.constraint(equalToConstant: 1),
            separator.leadingAnchor.constraint(equalTo: contentView.leadingAnchor, constant: 10),
            separator.trailingAnchor.constraint(equalTo: contentView.trailingAnchor, constant: -10),
            separator.bottomAnchor.constraint(equalTo: contentView.bottomAnchor)
        ])
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}

//
//  DiskCacheManager.swift
//  FetchProject
//
//  Created by Leslie Mora Ponce on 12/11/24.
//
import UIKit

class DiskCacheManager {
    // singleton
    static let shared = DiskCacheManager()
    private let cacheDirectory: URL

    private init() {
        
        //initialize cache directory if doesn't exist
        let paths = FileManager.default.urls(for: .cachesDirectory, in: .userDomainMask)
        cacheDirectory = paths[0].appendingPathComponent("ImageCache")
        
        if !FileManager.default.fileExists(atPath: cacheDirectory.path) {
            try? FileManager.default.createDirectory(at: cacheDirectory, withIntermediateDirectories: true, attributes: nil)
        }
    }

    func saveImage(_ image: UIImage, forKey key: String) {
        // convert uiimage to data and store it
        let fileURL = cacheDirectory.appendingPathComponent(key)
        if let data = image.jpegData(compressionQuality: 0.8) {
            try? data.write(to: fileURL, options: .atomic)
        }
    }

    func loadImage(forKey key: String) -> UIImage? {
        // read data and convert to uiimage if exist
        let fileURL = cacheDirectory.appendingPathComponent(key)
        if let data = try? Data(contentsOf: fileURL) {
            return UIImage(data: data)
        }
        return nil
    }

    func cacheKey(for url: URL) -> String {
        // because they are all named the same we're using the full url as key
        return url.absoluteString
    }
}


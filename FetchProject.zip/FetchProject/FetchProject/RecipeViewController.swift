import UIKit

class RecipeViewController: UIViewController {
    
    let nameLabel = UILabel()
    let cuisineLabel = UILabel()
    let imageView = UIImageView()
    let descriptionLabel = UILabel()
    let sourceUrlButton = UIButton()
    let youtubeUrlButton = UIButton()
    

    var recipe: Recipe?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .white
        setupUI()
        displayRecipeDetails()
    }
    
    func setupUI() {
        
        imageView.translatesAutoresizingMaskIntoConstraints = false
        imageView.contentMode = .scaleAspectFill
        imageView.clipsToBounds = true
        imageView.layer.cornerRadius = 15
        view.addSubview(imageView)
        
        NSLayoutConstraint.activate([
            imageView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 20),
            imageView.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            imageView.widthAnchor.constraint(equalToConstant: 300),
            imageView.heightAnchor.constraint(equalToConstant: 200)
        ])
        
        nameLabel.translatesAutoresizingMaskIntoConstraints = false
        nameLabel.font = UIFont.boldSystemFont(ofSize: 24)
        nameLabel.textAlignment = .center
        nameLabel.numberOfLines = 0
        view.addSubview(nameLabel)
        
        NSLayoutConstraint.activate([
            nameLabel.topAnchor.constraint(equalTo: imageView.bottomAnchor, constant: 15),
            nameLabel.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            nameLabel.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20)
        ])
        
        cuisineLabel.translatesAutoresizingMaskIntoConstraints = false
        cuisineLabel.font = UIFont.systemFont(ofSize: 18)
        cuisineLabel.textAlignment = .center
        cuisineLabel.textColor = .systemGray
        view.addSubview(cuisineLabel)
        
        NSLayoutConstraint.activate([
            cuisineLabel.topAnchor.constraint(equalTo: nameLabel.bottomAnchor, constant: 10),
            cuisineLabel.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            cuisineLabel.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20)
        ])
        
        descriptionLabel.translatesAutoresizingMaskIntoConstraints = false
        descriptionLabel.font = UIFont.systemFont(ofSize: 16)
        descriptionLabel.textColor = .darkGray
        descriptionLabel.numberOfLines = 0
        descriptionLabel.lineBreakMode = .byWordWrapping
        view.addSubview(descriptionLabel)
        
        NSLayoutConstraint.activate([
            descriptionLabel.topAnchor.constraint(equalTo: cuisineLabel.bottomAnchor, constant: 20),
            descriptionLabel.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            descriptionLabel.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20)
        ])
        

        sourceUrlButton.translatesAutoresizingMaskIntoConstraints = false
                sourceUrlButton.setTitle("Website", for: .normal)
                sourceUrlButton.setTitleColor(.white, for: .normal)
                sourceUrlButton.backgroundColor = .darkGray
                sourceUrlButton.layer.cornerRadius = 10
                sourceUrlButton.addTarget(self, action: #selector(openSourceUrl), for: .touchUpInside)
                view.addSubview(sourceUrlButton)
        
        NSLayoutConstraint.activate([
                    sourceUrlButton.topAnchor.constraint(equalTo: descriptionLabel.bottomAnchor, constant: 20),
                    sourceUrlButton.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
                    sourceUrlButton.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),
                    sourceUrlButton.heightAnchor.constraint(equalToConstant: 40)
                ])
        
        youtubeUrlButton.translatesAutoresizingMaskIntoConstraints = false
                youtubeUrlButton.setTitle("YouTube", for: .normal)
                youtubeUrlButton.setTitleColor(.white, for: .normal)
                youtubeUrlButton.backgroundColor = .darkGray
                youtubeUrlButton.layer.cornerRadius = 10
                youtubeUrlButton.addTarget(self, action: #selector(openYoutubeUrl), for: .touchUpInside)
                view.addSubview(youtubeUrlButton)
        
        NSLayoutConstraint.activate([
                    youtubeUrlButton.topAnchor.constraint(equalTo: sourceUrlButton.bottomAnchor, constant: 10),
                    youtubeUrlButton.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
                    youtubeUrlButton.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),
                    youtubeUrlButton.heightAnchor.constraint(equalToConstant: 40)
                ])
    }
    
    func displayRecipeDetails() {
        guard let recipe = recipe else { return }
        
     
        nameLabel.text = recipe.name
        cuisineLabel.text = "Cuisine: \(recipe.cuisine)"
        
        descriptionLabel.text = "Description: \(recipe.description ?? "No description available.")"
        
        if let imageUrlString = recipe.photoUrlLarge, let imageUrl = URL(string: imageUrlString) {
            URLSession.shared.dataTask(with: imageUrl) { data, _, error in
                if let data = data, error == nil, let image = UIImage(data: data) {
                    DispatchQueue.main.async {
                        self.imageView.image = image
                    }
                }
            }.resume()
        }
    }
    
    @objc func openSourceUrl() {
        if let urlString = recipe?.sourceUrl, let url = URL(string: urlString) {
            UIApplication.shared.open(url)
        }
    }
    
    @objc func openYoutubeUrl() {
        if let urlString = recipe?.youtubeUrl, let url = URL(string: urlString) {
            UIApplication.shared.open(url)
        }
    }
}
